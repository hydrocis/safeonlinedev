<?php get_header(); ?>
  
  
  <div id="listing">
    <div class="container">
      <div class="row">
        <div class="col-sm-9">
          <div class="wrapper">
            <?php get_template_part('loop'); ?>
          </div>

        </div>
      </div>
    </div>
  </div>


<?php get_footer(); ?>
