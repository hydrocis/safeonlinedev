<footer>
		<div class="container">
			<h4>The Safe Online Guide is brought to you by</h4>
			<div class="row">
				<div class="col-sm-offset-3 col-sm-6 col-xs-12">
					<ul>
						<li>
							<a href="http://cchubnigeria.com" target="_blank"><img src="<?php echo get_template_directory_uri(); ?>/assets/img/cchub.png" alt="Co-Creation Hub"></a>
						</li>
						<li class="pull-right">
							<a href="http://osiwa.org" target="_blank"><img src="<?php echo get_template_directory_uri(); ?>/assets/img/osiwa.png" alt="OSIWA"></a>
						</li>
					</ul>
				</div>
			</div>
		</div>
	</footer>
	

	<?php wp_footer(); ?>

	<!-- analytics -->
	<script>
	  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
	  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
	  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
	  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

	  ga('create', 'UA-46691706-27', 'auto');
	  ga('send', 'pageview');

	</script>

	</body>
</html>
